﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace wpfControlCreate
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            this.MouseDown += MainWindow_MouseDown;
        }

        private void MainWindow_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // if (e.LeftButton == MouseButtonState.Pressed) ...

            if (e.ChangedButton == MouseButton.Left)
            {
                var la = new Label();

                la.Background = Brushes.LightCoral;

                la.SetValue(Canvas.LeftProperty, e.GetPosition(this).X);
                la.SetValue(Canvas.TopProperty, e.GetPosition(this).Y);

                la.Content =
                    $"{la.GetValue(Canvas.LeftProperty)}:{la.GetValue(Canvas.TopProperty)}";

                main.Children.Add(la);
            }
        }
    }
}