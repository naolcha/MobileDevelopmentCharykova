﻿using System.Collections.ObjectModel;
using System.Windows;

namespace wpfTemplate
{
    public partial class MainWindow : Window
    {
        private ObservableCollection<MyTask> listTasks;
        private MyTask newTask;

        public MainWindow()
        {
            InitializeComponent();

            var listPhones = new ObservableCollection<string>
            {
                "iPhone 13",
                "HTC",
                "Samsung"
            };

            lbPhones.ItemsSource = listPhones;

            listTasks = new ObservableCollection<MyTask>
            {
                new MyTask
                {
                    Name = "Открыть ноутбук",
                    Description = "Свой ноутбук",
                    Priority = 3
                },
                new MyTask
                {
                    Name = "Выполнить ДЗ",
                    Priority = 1
                },
                new MyTask
                {
                    Name = "Закрыть ноутбук",
                    Description = "Выключить",
                    Priority = 5
                }
            };

            lbTasks.ItemsSource = listTasks;

            newTask = new MyTask();
            stackPanelAdd.DataContext = newTask;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            listTasks.Add(new MyTask
            {
                Name = newTask.Name,
                Description = newTask.Description,
                Priority = newTask.Priority
            });

            MessageBox.Show($"{newTask.Name}");
        }
    }

    internal class MyTask
    {
        public string Name { get; set; }

        public string Description { get; set; }

        public int Priority { get; set; }
    }
}