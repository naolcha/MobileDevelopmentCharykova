﻿using System.Windows;
using System.Windows.Input;

namespace WpfCommand
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void CommandNew_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            MessageBox.Show("CommandNew_Executed");
        }

        private void CommandSave_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            MessageBox.Show("CommandSave_Executed");
        }

        private void CommandSave_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }

        private void CommandBinding_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            edNote.Text += "*";
        }
    }

    public class MyCommands
    {
        public static RoutedCommand cmdAdd { get; private set; } =
            new RoutedCommand("cmdAdd", typeof(MainWindow));
    }
}