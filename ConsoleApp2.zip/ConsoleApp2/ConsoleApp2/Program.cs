﻿using SQLite;

namespace cnsSQLite
{
    internal class Program
    {
        private static SQLiteConnection db;

        static void Main(string[] args)
        {
            // Помним: установить "sqlite-net-pcl" через NuGet

            db = new SQLiteConnection("myDB.db");

            db.CreateTable<Logs>();
            db.CreateTable<Users>();

            db.Insert(new Logs() { DT = DateTime.Now });

            db.Insert(new Users() { FIO = "Ваня", Email = "111", Age = 10 });

            foreach (var logs in db.Table<Logs>())
            {
                Console.WriteLine($"{logs.DT.ToString()}");
            }

            //Console.WriteLine(string.Join(" | ", db.Table<Logs>().ToList()));

            foreach (var users in db.Table<Users>())
            {
                Console.WriteLine($" ID = {users.ID}, FIO={users.FIO}");
            }
        }
    }
}