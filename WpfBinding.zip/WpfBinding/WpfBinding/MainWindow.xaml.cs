﻿using System.ComponentModel;
using System.Windows;

namespace wpfBinding
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var herroEx = (HerroEx)this.Resources["myHerroEx"];

            herroEx.Name = "Name";
            herroEx.Clan = "Clan";
            herroEx.Description = "Маленькое объявление";
            herroEx.HP = 100;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var herroEx = (HerroEx)this.Resources["myHerroEx"];

            btnGetName.Content = herroEx.Name;
        }
    }

    public class HerroEx : INotifyPropertyChanged
    {
        private string? name;
        private string? clan;
        private string? description;
        private int hp = 100;

        public string? Name
        {
            get => name;
            set
            {
                name = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Name)));
            }
        }

        public string? Clan
        {
            get => clan;
            set
            {
                clan = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Clan)));
            }
        }

        public string? Description
        {
            get => description;
            set
            {
                description = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Description)));
            }
        }

        public int HP
        {
            get => hp;
            set
            {
                hp = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HP)));
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
    }
}