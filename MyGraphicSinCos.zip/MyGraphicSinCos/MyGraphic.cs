﻿namespace wfaGraphicSinCos
{
    internal class MyGraphic
    {
        public MyGraphic(int width, int height)
        {
            Width = width;
            Height = height;
        }

        public int Width { get; }

        public int Height { get; }

        internal void DrawAxes()
        {
            throw new NotImplementedException();
        }

        internal void DrawSin()
        {
            throw new NotImplementedException();
        }
    }
    internal Bitmap GetBitmap()
        {
            return new Bitmap(Width, Height);
        }
    }
