﻿namespace wfaGraphicSinCos
{
    internal class MyGraphic
    {
        public MyGraphic(int width, int height)
        {
            Width = width;
            Height = height;

            b = new Bitmap(Width, Height);
            g = Graphics.FromImage(b);

            grShiftY = Height / 2;
            grHeight = Height / 3;
        }

        public int Width { get; }
        public int Height { get; }

        public int DotDiameter { get; } = 4;
        public double CountWave { get; private set; } = 5;

        private Bitmap b;
        private Graphics g;
        private int grShiftY;
        private double grHeight;

        internal void DrawAxes()
        {
            Font font = new Font("Arial", 12);
            Brush brush = Brushes.Black;

            g.DrawLine(new Pen(Color.Black), 0, grShiftY, b.Width, grShiftY);

            for (int i = 0; i <= CountWave; i++)
            {
                var x = b.Width / CountWave * i;

                g.DrawLine(new Pen(Color.DarkGray), (int)x, grShiftY - 30, (int)x, grShiftY + 30);

                string text = i == 0 ? "0" : i == 1 ? "π" : $"{i}π";

                g.DrawString(text, font, brush, (int)x + 5, grShiftY + 8);
            }

            g.DrawLine(new Pen(Color.Black), 0, 0, 0, b.Height);
        }

        internal void DrawSin(Color color)
        {
            for (int i = 0; i < b.Width; i++)
            {
                double x = i;
                var grWidthPI = Math.PI / (b.Width - 1);
                double y = grShiftY + Math.Sin(i * grWidthPI * CountWave) * grHeight;

                g.FillEllipse(
                    new SolidBrush(color),
                    (int)x - DotDiameter / 2,
                    (int)y - DotDiameter / 2,
                    DotDiameter,
                    DotDiameter);
            }
        }

        internal void DrawCos(Color color)
        {
            for (int i = 0; i < b.Width; i++)
            {
                double x = i;
                var grWidthPI = Math.PI / (b.Width - 1);
                double y = grShiftY + Math.Cos(i * grWidthPI * CountWave) * grHeight;

                g.FillEllipse(
                    new SolidBrush(color),
                    (int)x - DotDiameter / 2,
                    (int)y - DotDiameter / 2,
                    DotDiameter,
                    DotDiameter);
            }
        }

        internal Bitmap GetBitmap()
        {
            return b;
        }
    }
}