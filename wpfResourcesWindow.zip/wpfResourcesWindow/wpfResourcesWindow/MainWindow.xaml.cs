﻿using System.Windows;
using System.Windows.Media;

namespace wpfResourcesWindow
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Resources["Background_play"] = new SolidColorBrush(Colors.Orange);
        }

        private void buChange_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}